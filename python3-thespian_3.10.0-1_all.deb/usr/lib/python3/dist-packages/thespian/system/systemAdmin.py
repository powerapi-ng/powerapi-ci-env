from thespian.system.admin.convention import ConventioneerAdmin

class ThespianAdmin(ConventioneerAdmin): pass
